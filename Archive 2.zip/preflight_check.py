#!/usr/bin/env python3
"""
Pre-flight smoke test for Lara_Croft_GO_Diorama.mcpack
Run this BEFORE importing into Bedrock to catch any structural issues.

Usage: python3 preflight_check.py [path/to/Lara_Croft_GO_Diorama.mcpack]
"""
import sys, json, zipfile
from pathlib import Path

def check(pack_path):
    issues = []
    ok = []
    
    if not Path(pack_path).exists():
        print(f"FAIL: Pack not found: {pack_path}")
        return False
    
    with zipfile.ZipFile(pack_path) as z:
        names = z.namelist()
        
        # 1. manifest.json exists and is valid
        if 'manifest.json' not in names:
            issues.append("manifest.json missing")
        else:
            try:
                m = json.loads(z.read('manifest.json'))
                if m.get('format_version') != 2:
                    issues.append(f"manifest format_version should be 2, got {m.get('format_version')}")
                else:
                    ok.append("manifest format_version = 2")
                if not m.get('header', {}).get('uuid'):
                    issues.append("manifest header.uuid missing")
                else:
                    ok.append("header UUID present")
                if not m.get('modules', [{}])[0].get('uuid'):
                    issues.append("manifest modules[0].uuid missing")
                else:
                    ok.append("module UUID present")
                min_eng = m.get('header', {}).get('min_engine_version', [])
                if min_eng != [1, 21, 0]:
                    issues.append(f"min_engine_version should be [1,21,0], got {min_eng}")
                else:
                    ok.append("min_engine_version = 1.21.0")
            except Exception as e:
                issues.append(f"manifest.json parse error: {e}")
        
        # 2. pack_icon.png exists and is 256x256
        if 'pack_icon.png' not in names:
            issues.append("pack_icon.png missing")
        else:
            from PIL import Image
            import io
            img = Image.open(io.BytesIO(z.read('pack_icon.png')))
            if img.size != (256, 256):
                issues.append(f"pack_icon.png should be 256x256, got {img.size}")
            else:
                ok.append("pack_icon.png 256x256")
        
        # 3. All block textures are 16x16
        from PIL import Image
        import io
        block_textures = [n for n in names if n.startswith('textures/blocks/') and n.endswith('.png')]
        for bt in block_textures:
            img = Image.open(io.BytesIO(z.read(bt)))
            if img.size != (16, 16):
                issues.append(f"{bt} should be 16x16, got {img.size}")
        if not issues or not any('16x16' in i for i in issues):
            ok.append(f"{len(block_textures)} block textures all 16x16")
        
        # 4. All item textures are 16x16 with alpha
        item_textures = [n for n in names if n.startswith('textures/items/') and n.endswith('.png')]
        for it in item_textures:
            img = Image.open(io.BytesIO(z.read(it)))
            if img.size != (16, 16):
                issues.append(f"{it} should be 16x16, got {img.size}")
            if img.mode != 'RGBA':
                issues.append(f"{it} should be RGBA, got {img.mode}")
        if item_textures and not any('items' in i for i in issues):
            ok.append(f"{len(item_textures)} item textures all 16x16 RGBA")
        
        # 5. Expected block paths
        expected_blocks = [
            'textures/blocks/calcite.png',
            'textures/blocks/stone.png',
            'textures/blocks/deepslate/deepslate.png',
            'textures/blocks/bedrock.png',
            'textures/blocks/sand.png',
            'textures/blocks/dirt.png',
            'textures/blocks/cobblestone.png',
            'textures/blocks/log_oak_top.png',
            'textures/blocks/log_oak.png',
            'textures/blocks/leaves_oak.png',
            'textures/blocks/leaves_oak_opaque.png',
            'textures/blocks/water_still_grey.png',
            'textures/blocks/gold_block.png',
            'textures/blocks/emerald_block.png',
            'textures/blocks/copper_block.png',
        ]
        missing_blocks = [b for b in expected_blocks if b not in names]
        if missing_blocks:
            issues.append(f"Missing block textures: {missing_blocks}")
        else:
            ok.append(f"All {len(expected_blocks)} expected block textures present")
        
        # 6. Expected item paths
        expected_items = [
            'textures/items/chorus_fruit.png',
            'textures/items/zombie_head.png',
            'textures/items/iron_ingot.png',
            'textures/items/prismarine_crystals.png',
            'textures/items/trident.png',
        ]
        missing_items = [i for i in expected_items if i not in names]
        if missing_items:
            issues.append(f"Missing item textures: {missing_items}")
        else:
            ok.append(f"All {len(expected_items)} expected item textures present")
        
        # 7. UI textures
        if 'textures/ui/hotbar_start_cap.png' not in names:
            issues.append("hotbar_start_cap.png missing")
        else:
            ok.append("hotbar_start_cap.png present")
        if 'textures/ui/title.png' not in names:
            issues.append("title.png missing")
        else:
            ok.append("title.png present")
        
        # 8. No stray files
        expected_count = 1 + 1 + 15 + 5 + 2  # manifest + icon + blocks + items + ui
        if len(names) != expected_count:
            issues.append(f"Unexpected file count: {len(names)} (expected {expected_count})")
    
    print("=" * 60)
    print(f"PREFLIGHT CHECK: {pack_path}")
    print("=" * 60)
    print(f"\n✓ PASSED ({len(ok)} checks):")
    for o in ok:
        print(f"  {o}")
    if issues:
        print(f"\n✗ FAILED ({len(issues)} issues):")
        for i in issues:
            print(f"  {i}")
        print(f"\nResult: FAIL — do not import")
        return False
    else:
        print(f"\nResult: PASS — safe to import into Bedrock 1.21+")
        return True

if __name__ == '__main__':
    pack = sys.argv[1] if len(sys.argv) > 1 else '/home/z/my-project/download/Lara_Croft_GO_Diorama.mcpack'
    success = check(pack)
    sys.exit(0 if success else 1)
